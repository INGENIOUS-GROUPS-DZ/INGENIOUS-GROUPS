import { useState, useEffect, useRef } from "react";
import { motion, useScroll, useTransform, AnimatePresence } from "framer-motion";
import { useInView } from "react-intersection-observer";

// ─── Eagle Logo SVG ───────────────────────────────────────────────────────────
const EagleLogo = ({ size = 80 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 200 200" fill="none" xmlns="http://www.w3.org/2000/svg">
    {/* Body */}
    <ellipse cx="100" cy="130" rx="28" ry="38" fill="#1a1a1a" stroke="#cc0000" strokeWidth="1.5"/>
    {/* Head */}
    <circle cx="100" cy="78" r="26" fill="#1a1a1a" stroke="#cc0000" strokeWidth="1.5"/>
    {/* Angry brow left */}
    <path d="M78 65 Q88 58 98 62" stroke="#cc0000" strokeWidth="3" strokeLinecap="round" fill="none"/>
    {/* Angry brow right */}
    <path d="M102 62 Q112 58 122 65" stroke="#cc0000" strokeWidth="3" strokeLinecap="round" fill="none"/>
    {/* Eyes */}
    <circle cx="88" cy="72" r="6" fill="#cc0000"/>
    <circle cx="112" cy="72" r="6" fill="#cc0000"/>
    <circle cx="89" cy="71" r="2.5" fill="#111"/>
    <circle cx="113" cy="71" r="2.5" fill="#111"/>
    <circle cx="90" cy="70" r="1" fill="white"/>
    <circle cx="114" cy="70" r="1" fill="white"/>
    {/* Beak */}
    <path d="M94 84 L100 96 L106 84 Q100 80 94 84Z" fill="#cc0000"/>
    <path d="M94 84 Q100 88 106 84" stroke="#8B0000" strokeWidth="1" fill="none"/>
    {/* Left Wing */}
    <path d="M72 118 Q40 100 18 80 Q30 95 35 118 Q50 108 72 118Z" fill="#1a1a1a" stroke="#cc0000" strokeWidth="1.5"/>
    <path d="M72 118 Q45 115 22 105" stroke="#333" strokeWidth="1" fill="none"/>
    <path d="M72 118 Q50 120 28 112" stroke="#333" strokeWidth="1" fill="none"/>
    {/* Right Wing */}
    <path d="M128 118 Q160 100 182 80 Q170 95 165 118 Q150 108 128 118Z" fill="#1a1a1a" stroke="#cc0000" strokeWidth="1.5"/>
    <path d="M128 118 Q155 115 178 105" stroke="#333" strokeWidth="1" fill="none"/>
    <path d="M128 118 Q150 120 172 112" stroke="#333" strokeWidth="1" fill="none"/>
    {/* Chest feathers */}
    <path d="M85 108 Q100 115 115 108" stroke="#cc0000" strokeWidth="1" fill="none"/>
    <path d="M82 120 Q100 128 118 120" stroke="#cc0000" strokeWidth="1" fill="none"/>
    {/* Talons */}
    <path d="M88 165 L82 180 M88 165 L86 182 M88 165 L92 180" stroke="#cc0000" strokeWidth="2" strokeLinecap="round"/>
    <path d="M112 165 L106 180 M112 165 L112 182 M112 165 L118 180" stroke="#cc0000" strokeWidth="2" strokeLinecap="round"/>
    {/* Crown/feathers on head */}
    <path d="M90 54 Q85 40 88 30 Q93 42 90 54Z" fill="#cc0000"/>
    <path d="M100 52 Q100 36 100 25 Q104 38 100 52Z" fill="#cc0000"/>
    <path d="M110 54 Q115 40 112 30 Q107 42 110 54Z" fill="#cc0000"/>
  </svg>
);

// ─── Particle Background ───────────────────────────────────────────────────────
const ParticleField = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    const particles: { x: number; y: number; vx: number; vy: number; size: number; color: string; alpha: number }[] = [];
    const colors = ["#cc0000", "#ff3333", "#ffffff", "#8B0000"];
    for (let i = 0; i < 80; i++) {
      particles.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        vx: (Math.random() - 0.5) * 0.6,
        vy: (Math.random() - 0.5) * 0.6,
        size: Math.random() * 2.5 + 0.5,
        color: colors[Math.floor(Math.random() * colors.length)],
        alpha: Math.random() * 0.7 + 0.3,
      });
    }
    let animId: number;
    const draw = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      particles.forEach((p) => {
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fillStyle = p.color;
        ctx.globalAlpha = p.alpha;
        ctx.fill();
        p.x += p.vx;
        p.y += p.vy;
        if (p.x < 0 || p.x > canvas.width) p.vx *= -1;
        if (p.y < 0 || p.y > canvas.height) p.vy *= -1;
      });
      // draw lines between close particles
      for (let i = 0; i < particles.length; i++) {
        for (let j = i + 1; j < particles.length; j++) {
          const dx = particles[i].x - particles[j].x;
          const dy = particles[i].y - particles[j].y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < 120) {
            ctx.beginPath();
            ctx.moveTo(particles[i].x, particles[i].y);
            ctx.lineTo(particles[j].x, particles[j].y);
            ctx.strokeStyle = "#cc0000";
            ctx.globalAlpha = 0.08 * (1 - dist / 120);
            ctx.lineWidth = 0.5;
            ctx.stroke();
          }
        }
      }
      ctx.globalAlpha = 1;
      animId = requestAnimationFrame(draw);
    };
    draw();
    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    window.addEventListener("resize", resize);
    return () => { cancelAnimationFrame(animId); window.removeEventListener("resize", resize); };
  }, []);
  return <canvas ref={canvasRef} className="absolute inset-0 w-full h-full pointer-events-none z-0" />;
};

// ─── 3D Rotating Card ─────────────────────────────────────────────────────────
const Card3D = ({ children, className = "" }: { children: React.ReactNode; className?: string }) => {
  const ref = useRef<HTMLDivElement>(null);
  const handleMove = (e: React.MouseEvent) => {
    const el = ref.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width - 0.5) * 20;
    const y = -((e.clientY - rect.top) / rect.height - 0.5) * 20;
    el.style.transform = `perspective(600px) rotateY(${x}deg) rotateX(${y}deg) scale3d(1.04,1.04,1.04)`;
  };
  const handleLeave = () => {
    if (ref.current) ref.current.style.transform = "perspective(600px) rotateY(0deg) rotateX(0deg) scale3d(1,1,1)";
  };
  return (
    <div
      ref={ref}
      onMouseMove={handleMove}
      onMouseLeave={handleLeave}
      className={className}
      style={{ transition: "transform 0.15s ease", transformStyle: "preserve-3d" }}
    >
      {children}
    </div>
  );
};

// ─── Section wrapper with fade-in ─────────────────────────────────────────────
const FadeSection = ({ children, className = "" }: { children: React.ReactNode; className?: string }) => {
  const { ref, inView } = useInView({ threshold: 0.15, triggerOnce: true });
  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 60 }}
      animate={inView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.8, ease: "easeOut" }}
      className={className}
    >
      {children}
    </motion.div>
  );
};

// ─── Nav ──────────────────────────────────────────────────────────────────────
const navLinks = ["Accueil", "Services", "Technologies", "Réalisations", "Contact"];

const Navbar = () => {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
    setOpen(false);
  };
  const ids = ["hero", "services", "technologies", "realisations", "contact"];
  return (
    <motion.nav
      initial={{ y: -80 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.7 }}
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${scrolled ? "bg-black/95 shadow-lg shadow-red-900/30" : "bg-black/70"} backdrop-blur-md border-b border-red-900/30`}
    >
      <div className="max-w-7xl mx-auto px-4 flex items-center justify-between h-18 py-3">
        <div className="flex items-center gap-3">
          <motion.div whileHover={{ rotate: 10, scale: 1.1 }} transition={{ type: "spring" }}>
            <EagleLogo size={52} />
          </motion.div>
          <div>
            <div className="text-white font-black text-xl leading-none tracking-wider" style={{ fontFamily: "Raleway, sans-serif" }}>
              INGENIOUS
            </div>
            <div className="text-red-500 font-bold text-sm tracking-[0.25em]" style={{ fontFamily: "Montserrat, sans-serif" }}>
              GROUPS
            </div>
          </div>
        </div>
        {/* Desktop */}
        <div className="hidden md:flex gap-8">
          {navLinks.map((l, i) => (
            <button key={l} onClick={() => scrollTo(ids[i])}
              className="text-gray-300 hover:text-red-500 transition-colors font-semibold text-sm tracking-wide uppercase"
              style={{ fontFamily: "Montserrat, sans-serif" }}>
              {l}
            </button>
          ))}
        </div>
        {/* Hamburger */}
        <button className="md:hidden text-white" onClick={() => setOpen(!open)}>
          <div className="w-6 h-0.5 bg-white mb-1.5 transition-all" />
          <div className="w-6 h-0.5 bg-red-500 mb-1.5" />
          <div className="w-6 h-0.5 bg-white" />
        </button>
      </div>
      <AnimatePresence>
        {open && (
          <motion.div initial={{ height: 0 }} animate={{ height: "auto" }} exit={{ height: 0 }}
            className="md:hidden bg-black/98 overflow-hidden border-t border-red-900/40">
            {navLinks.map((l, i) => (
              <button key={l} onClick={() => scrollTo(ids[i])}
                className="block w-full text-left px-6 py-3 text-gray-300 hover:text-red-500 hover:bg-red-950/30 transition-colors font-semibold text-sm tracking-wide uppercase"
                style={{ fontFamily: "Montserrat, sans-serif" }}>
                {l}
              </button>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </motion.nav>
  );
};

// ─── Hero ─────────────────────────────────────────────────────────────────────
const Hero = () => {
  const { scrollY } = useScroll();
  const y = useTransform(scrollY, [0, 500], [0, 150]);
  const opacity = useTransform(scrollY, [0, 400], [1, 0]);
  const words = ["INGENIOUS", "GROUPS"];
  return (
    <section id="hero" className="relative min-h-screen flex items-center justify-center overflow-hidden bg-black">
      <ParticleField />
      {/* Animated grid lines */}
      <div className="absolute inset-0 z-0 pointer-events-none"
        style={{ backgroundImage: "linear-gradient(rgba(204,0,0,0.05) 1px, transparent 1px), linear-gradient(90deg, rgba(204,0,0,0.05) 1px, transparent 1px)", backgroundSize: "60px 60px" }} />
      {/* Red glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full bg-red-700/10 blur-[120px] pointer-events-none z-0" />
      <motion.div style={{ y, opacity }} className="relative z-10 text-center px-4">
        {/* Eagle */}
        <motion.div
          initial={{ scale: 0, rotate: -30 }}
          animate={{ scale: 1, rotate: 0 }}
          transition={{ type: "spring", stiffness: 80, delay: 0.3 }}
          className="flex justify-center mb-6"
        >
          <motion.div
            animate={{ y: [0, -12, 0] }}
            transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
            style={{ filter: "drop-shadow(0 0 30px rgba(204,0,0,0.8))" }}
          >
            <EagleLogo size={140} />
          </motion.div>
        </motion.div>
        {/* Title */}
        <div className="overflow-hidden mb-2">
          {words.map((w, wi) => (
            <motion.div key={w}
              initial={{ y: 100, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.8, delay: 0.5 + wi * 0.15, ease: "easeOut" }}
            >
              <span className={`block font-black tracking-[0.15em] leading-none ${wi === 0 ? "text-white text-6xl md:text-8xl" : "text-red-600 text-5xl md:text-7xl"}`}
                style={{ fontFamily: "Raleway, sans-serif" }}>
                {w}
              </span>
            </motion.div>
          ))}
        </div>
        {/* Tagline */}
        <motion.div
          initial={{ opacity: 0, scaleX: 0 }}
          animate={{ opacity: 1, scaleX: 1 }}
          transition={{ duration: 0.8, delay: 1 }}
          className="h-0.5 bg-gradient-to-r from-transparent via-red-600 to-transparent max-w-lg mx-auto my-5"
        />
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 1.1 }}
          className="text-gray-300 text-lg md:text-xl font-light tracking-widest mb-2"
          style={{ fontFamily: "Montserrat, sans-serif" }}
        >
          Design · Impression · Innovation
        </motion.p>
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 1.25 }}
          className="text-red-400 text-sm md:text-base tracking-[0.3em] uppercase mb-8"
          style={{ fontFamily: "Montserrat, sans-serif" }}
        >
          Impression Flexo · Standards Internationaux
        </motion.p>
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6, delay: 1.4 }}
          className="flex flex-col sm:flex-row gap-4 justify-center"
        >
          <motion.button
            whileHover={{ scale: 1.06, boxShadow: "0 0 30px rgba(204,0,0,0.6)" }}
            whileTap={{ scale: 0.97 }}
            onClick={() => document.getElementById("services")?.scrollIntoView({ behavior: "smooth" })}
            className="px-8 py-3.5 bg-red-600 text-white font-bold tracking-widest uppercase text-sm rounded-sm border border-red-500 hover:bg-red-700 transition-colors"
            style={{ fontFamily: "Montserrat, sans-serif" }}
          >
            Nos Services
          </motion.button>
          <motion.button
            whileHover={{ scale: 1.06, boxShadow: "0 0 30px rgba(255,255,255,0.15)" }}
            whileTap={{ scale: 0.97 }}
            onClick={() => document.getElementById("contact")?.scrollIntoView({ behavior: "smooth" })}
            className="px-8 py-3.5 bg-transparent text-white font-bold tracking-widest uppercase text-sm rounded-sm border border-white/30 hover:border-red-500 hover:text-red-400 transition-all"
            style={{ fontFamily: "Montserrat, sans-serif" }}
          >
            Contactez-nous
          </motion.button>
        </motion.div>
        {/* Scroll indicator */}
        <motion.div
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 1.5, repeat: Infinity }}
          className="mt-16 flex flex-col items-center gap-2"
        >
          <span className="text-gray-500 text-xs tracking-widest uppercase" style={{ fontFamily: "Montserrat, sans-serif" }}>Défiler</span>
          <div className="w-0.5 h-10 bg-gradient-to-b from-red-600 to-transparent" />
        </motion.div>
      </motion.div>
    </section>
  );
};

// ─── Services ─────────────────────────────────────────────────────────────────
const services = [
  {
    icon: "🍽️",
    title: "Design Alimentaire",
    desc: "Conception graphique d'emballages pour produits alimentaires. Visuels attractifs qui respectent les normes de l'industrie et captivent les consommateurs.",
    tags: ["Packaging", "Étiquettes", "Branding"],
  },
  {
    icon: "💊",
    title: "Design Pharmaceutique",
    desc: "Création d'emballages et d'étiquettes pharmaceutiques conformes aux réglementations strictes, alliant clarté, sécurité et esthétique.",
    tags: ["Conformité", "Sécurité", "Clarté"],
  },
  {
    icon: "💄",
    title: "Design Cosmétique",
    desc: "Conception premium pour produits cosmétiques et de beauté. Packaging élégant qui reflète l'identité de la marque et attire le consommateur.",
    tags: ["Luxe", "Premium", "Tendance"],
  },
  {
    icon: "🖨️",
    title: "Impression Flexo",
    desc: "Impression flexographique aux standards internationaux, garantissant couleurs fidèles, qualité constante et conformité aux exigences des marchés mondiaux.",
    tags: ["ISO", "PANTONE", "Précision"],
  },
];

const Services = () => (
  <section id="services" className="py-24 bg-black relative overflow-hidden">
    <div className="absolute inset-0 pointer-events-none"
      style={{ backgroundImage: "radial-gradient(circle at 20% 80%, rgba(204,0,0,0.07) 0%, transparent 60%)" }} />
    <div className="max-w-7xl mx-auto px-4">
      <FadeSection>
        <div className="text-center mb-16">
          <motion.span className="inline-block text-red-500 text-xs font-bold tracking-[0.4em] uppercase mb-4"
            style={{ fontFamily: "Montserrat, sans-serif" }}>
            — Ce Que Nous Faisons —
          </motion.span>
          <h2 className="text-5xl md:text-6xl font-black text-white mb-4" style={{ fontFamily: "Raleway, sans-serif" }}>
            Nos <span className="text-red-600">Services</span>
          </h2>
          <div className="h-0.5 bg-gradient-to-r from-transparent via-red-600 to-transparent max-w-xs mx-auto" />
        </div>
      </FadeSection>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {services.map((s, i) => (
          <FadeSection key={s.title}>
            <motion.div
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.12, duration: 0.6 }}
              viewport={{ once: true }}
            >
              <Card3D className="h-full">
                <div className="h-full bg-gradient-to-b from-zinc-900 to-zinc-950 border border-red-900/30 rounded-sm p-6 flex flex-col gap-4 hover:border-red-600/60 transition-all duration-300 relative overflow-hidden group">
                  <div className="absolute top-0 left-0 right-0 h-0.5 bg-gradient-to-r from-transparent via-red-600 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                  <div className="text-5xl mb-2">{s.icon}</div>
                  <h3 className="text-white font-bold text-lg" style={{ fontFamily: "Raleway, sans-serif" }}>{s.title}</h3>
                  <p className="text-gray-400 text-sm leading-relaxed flex-1" style={{ fontFamily: "Montserrat, sans-serif" }}>{s.desc}</p>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {s.tags.map(t => (
                      <span key={t} className="text-xs px-2 py-0.5 bg-red-950/40 text-red-400 border border-red-900/50 rounded-sm font-semibold tracking-wider"
                        style={{ fontFamily: "Montserrat, sans-serif" }}>{t}</span>
                    ))}
                  </div>
                </div>
              </Card3D>
            </motion.div>
          </FadeSection>
        ))}
      </div>
    </div>
  </section>
);

// ─── Technologies (Xeikon & HP) ───────────────────────────────────────────────
const XeikonMachine = () => (
  <svg viewBox="0 0 320 200" className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
    {/* Machine body */}
    <rect x="20" y="60" width="280" height="110" rx="8" fill="#1a1a1a" stroke="#cc0000" strokeWidth="1.5"/>
    {/* Top panel */}
    <rect x="20" y="40" width="280" height="30" rx="6" fill="#111" stroke="#cc0000" strokeWidth="1"/>
    {/* Screen */}
    <rect x="30" y="48" width="90" height="18" rx="3" fill="#0d1f0d" stroke="#00aa00" strokeWidth="0.8"/>
    <text x="75" y="60" textAnchor="middle" fill="#00ff44" fontSize="7" fontFamily="monospace">XEIKON 3300</text>
    {/* Control panel buttons */}
    <circle cx="155" cy="57" r="5" fill="#cc0000" stroke="#ff3333" strokeWidth="0.5"/>
    <circle cx="170" cy="57" r="5" fill="#333" stroke="#555" strokeWidth="0.5"/>
    <circle cx="185" cy="57" r="5" fill="#cc6600" stroke="#ff8800" strokeWidth="0.5"/>
    {/* Paper roll left */}
    <ellipse cx="35" cy="115" rx="12" ry="40" fill="#222" stroke="#cc0000" strokeWidth="1"/>
    <ellipse cx="35" cy="115" rx="6" ry="33" fill="#111" stroke="#555" strokeWidth="0.5"/>
    {/* Paper roll right */}
    <ellipse cx="285" cy="115" rx="12" ry="40" fill="#222" stroke="#cc0000" strokeWidth="1"/>
    <ellipse cx="285" cy="115" rx="6" ry="33" fill="#111" stroke="#555" strokeWidth="0.5"/>
    {/* Paper feed line */}
    <line x1="47" y1="115" x2="273" y2="115" stroke="#f0f0f0" strokeWidth="2" opacity="0.6"/>
    {/* Printing heads */}
    {[70,110,150,190,230].map((x, i) => (
      <g key={i}>
        <rect x={x-10} y="80" width="20" height="30" rx="3" fill={["#cc0000","#0066cc","#ffcc00","#009933","#cc00cc"][i]} stroke="#333" strokeWidth="0.8" opacity="0.85"/>
        <rect x={x-6} y="106" width="12" height="6" rx="1" fill="#111" stroke="#555" strokeWidth="0.5"/>
      </g>
    ))}
    {/* Bottom feet */}
    <rect x="40" y="168" width="20" height="14" rx="2" fill="#111" stroke="#444"/>
    <rect x="260" y="168" width="20" height="14" rx="2" fill="#111" stroke="#444"/>
    {/* Brand label */}
    <rect x="85" y="140" width="150" height="22" rx="3" fill="#0d0d0d" stroke="#cc0000" strokeWidth="0.8"/>
    <text x="160" y="155" textAnchor="middle" fill="#cc0000" fontSize="10" fontFamily="Raleway, sans-serif" fontWeight="bold">XEIKON</text>
  </svg>
);

const HPMachine = () => (
  <svg viewBox="0 0 320 200" className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
    {/* Machine body */}
    <rect x="15" y="45" width="290" height="130" rx="10" fill="#1a1a1a" stroke="#0066cc" strokeWidth="1.5"/>
    {/* Top curve */}
    <path d="M15 60 Q15 45 25 45 L295 45 Q305 45 305 60" fill="#111" stroke="#0066cc" strokeWidth="1"/>
    {/* HP Logo area */}
    <rect x="25" y="52" width="60" height="30" rx="4" fill="#0066cc" stroke="#0055aa" strokeWidth="0.5"/>
    <text x="55" y="72" textAnchor="middle" fill="white" fontSize="16" fontFamily="Arial" fontWeight="bold">hp</text>
    {/* Control screen */}
    <rect x="95" y="52" width="130" height="28" rx="4" fill="#0d1a2e" stroke="#0066cc" strokeWidth="0.8"/>
    <text x="160" y="64" textAnchor="middle" fill="#00aaff" fontSize="6" fontFamily="monospace">HP INDIGO 7K</text>
    <text x="160" y="74" textAnchor="middle" fill="#0066cc" fontSize="5" fontFamily="monospace">STATUS: PRINTING...</text>
    {/* Status lights */}
    <circle cx="245" cy="58" r="5" fill="#00ff44" opacity="0.9"/>
    <circle cx="258" cy="58" r="5" fill="#0066cc" opacity="0.9"/>
    <circle cx="271" cy="58" r="5" fill="#ff6600" opacity="0.9"/>
    {/* Large output tray */}
    <rect x="25" y="90" width="270" height="60" rx="5" fill="#111" stroke="#333" strokeWidth="0.8"/>
    {/* Color cartridges */}
    {["#cc0000","#0066cc","#ffcc00","#111","#cc00cc","#00aa44"].map((c,i) => (
      <rect key={i} x={30 + i*43} y="95" width="35" height="48" rx="3" fill={c} stroke="#222" strokeWidth="0.5" opacity="0.85"/>
    ))}
    {/* Print head bar */}
    <rect x="15" y="82" width="290" height="8" rx="2" fill="#0d0d0d" stroke="#0066cc" strokeWidth="0.5"/>
    {/* Paper output */}
    <rect x="100" y="153" width="120" height="18" rx="2" fill="#f5f5f5" stroke="#ccc" strokeWidth="0.5"/>
    <line x1="105" y1="157" x2="215" y2="157" stroke="#ddd" strokeWidth="0.5"/>
    <line x1="105" y1="162" x2="215" y2="162" stroke="#ddd" strokeWidth="0.5"/>
    {/* Brand label */}
    <rect x="90" y="172" width="140" height="16" rx="2" fill="#0d0d0d" stroke="#0066cc" strokeWidth="0.8"/>
    <text x="160" y="183" textAnchor="middle" fill="#0066cc" fontSize="8" fontFamily="Arial" fontWeight="bold">HP INDIGO SERIES</text>
  </svg>
);

const Technologies = () => {
  const techs = [
    {
      name: "XEIKON",
      subtitle: "Impression Numérique Industrielle",
      model: "Xeikon 3300 / CX3",
      desc: "Les machines XEIKON offrent une qualité d'impression exceptionnelle pour étiquettes et emballages flexibles. Résolution ultra-haute, vitesse industrielle et couleurs PANTONE fidèles.",
      specs: ["Résolution 1200 DPI", "Vitesse 30m/min", "Laize jusqu'à 508mm", "Compatible Flexo & Digital"],
      color: "#cc0000",
      Machine: XeikonMachine,
    },
    {
      name: "HP INDIGO",
      subtitle: "Impression Offset Digitale",
      model: "HP Indigo 7K / 8K",
      desc: "La technologie HP Indigo révolutionne l'impression sur étiquettes pharmaceutiques, cosmétiques et alimentaires avec une qualité offset à tirage variable.",
      specs: ["7 couleurs ElectroInk", "Impression variable", "Substrats multiples", "Certifications FDA/ISO"],
      color: "#0066cc",
      Machine: HPMachine,
    },
  ];
  return (
    <section id="technologies" className="py-24 bg-zinc-950 relative overflow-hidden">
      <div className="absolute inset-0 pointer-events-none"
        style={{ backgroundImage: "radial-gradient(circle at 80% 20%, rgba(204,0,0,0.06) 0%, transparent 60%)" }} />
      <div className="max-w-7xl mx-auto px-4">
        <FadeSection>
          <div className="text-center mb-16">
            <span className="inline-block text-red-500 text-xs font-bold tracking-[0.4em] uppercase mb-4"
              style={{ fontFamily: "Montserrat, sans-serif" }}>
              — Équipements de Pointe —
            </span>
            <h2 className="text-5xl md:text-6xl font-black text-white mb-4" style={{ fontFamily: "Raleway, sans-serif" }}>
              Nos <span className="text-red-600">Technologies</span>
            </h2>
            <div className="h-0.5 bg-gradient-to-r from-transparent via-red-600 to-transparent max-w-xs mx-auto" />
          </div>
        </FadeSection>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
          {techs.map((t, i) => (
            <FadeSection key={t.name}>
              <Card3D>
                <div className={`bg-gradient-to-br from-zinc-900 via-zinc-900 to-black border rounded-sm p-6 relative overflow-hidden`}
                  style={{ borderColor: t.color + "44" }}>
                  {/* Glow */}
                  <div className="absolute -top-10 -right-10 w-40 h-40 rounded-full blur-3xl opacity-20 pointer-events-none"
                    style={{ backgroundColor: t.color }} />
                  {/* Badge */}
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <h3 className="text-3xl font-black text-white" style={{ fontFamily: "Raleway, sans-serif", color: t.color }}>{t.name}</h3>
                      <p className="text-gray-400 text-xs tracking-widest uppercase" style={{ fontFamily: "Montserrat, sans-serif" }}>{t.subtitle}</p>
                    </div>
                    <span className="text-xs px-3 py-1 font-bold tracking-wider border rounded-sm"
                      style={{ color: t.color, borderColor: t.color + "66", backgroundColor: t.color + "11", fontFamily: "Montserrat, sans-serif" }}>
                      {t.model}
                    </span>
                  </div>
                  {/* Machine illustration */}
                  <motion.div
                    className="w-full h-44 mb-5 rounded overflow-hidden bg-black/40 flex items-center justify-center p-2"
                    whileHover={{ scale: 1.02 }}
                    animate={{ y: [0, -4, 0] }}
                    transition={{ duration: 3 + i, repeat: Infinity, ease: "easeInOut" }}
                    style={{ filter: `drop-shadow(0 0 18px ${t.color}55)` }}
                  >
                    <t.Machine />
                  </motion.div>
                  <p className="text-gray-400 text-sm leading-relaxed mb-4" style={{ fontFamily: "Montserrat, sans-serif" }}>{t.desc}</p>
                  <div className="grid grid-cols-2 gap-2">
                    {t.specs.map(sp => (
                      <div key={sp} className="flex items-center gap-2 text-xs text-gray-300" style={{ fontFamily: "Montserrat, sans-serif" }}>
                        <div className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ backgroundColor: t.color }} />
                        {sp}
                      </div>
                    ))}
                  </div>
                </div>
              </Card3D>
            </FadeSection>
          ))}
        </div>
      </div>
    </section>
  );
};

// ─── Réalisations / Labels Gallery ────────────────────────────────────────────
const labels = [
  { name: "Yaourt Premium", category: "Alimentaire", color: "#e8f5e9", accent: "#2e7d32", icon: "🥛", bg: "from-green-900 to-green-950", pattern: "circles" },
  { name: "Sirop Médical", category: "Pharmaceutique", color: "#e3f2fd", accent: "#1565c0", icon: "💊", bg: "from-blue-900 to-blue-950", pattern: "lines" },
  { name: "Crème Luxe", category: "Cosmétique", color: "#fce4ec", accent: "#c62828", icon: "✨", bg: "from-pink-900 to-pink-950", pattern: "dots" },
  { name: "Eau Minérale", category: "Alimentaire", color: "#e0f7fa", accent: "#00838f", icon: "💧", bg: "from-cyan-900 to-cyan-950", pattern: "waves" },
  { name: "Antibiotique", category: "Pharmaceutique", color: "#f3e5f5", accent: "#6a1b9a", icon: "🔬", bg: "from-purple-900 to-purple-950", pattern: "circles" },
  { name: "Sérum Visage", category: "Cosmétique", color: "#fff8e1", accent: "#f57f17", icon: "🌟", bg: "from-amber-900 to-amber-950", pattern: "dots" },
];

const LabelCard = ({ l, i }: { l: typeof labels[0]; i: number }) => (
  <motion.div
    initial={{ opacity: 0, rotateY: -30, z: -100 }}
    whileInView={{ opacity: 1, rotateY: 0, z: 0 }}
    transition={{ delay: i * 0.1, duration: 0.7, type: "spring" }}
    viewport={{ once: true }}
    style={{ transformStyle: "preserve-3d" }}
  >
    <Card3D>
      <div className={`relative bg-gradient-to-br ${l.bg} border border-white/10 rounded-sm overflow-hidden group cursor-pointer`} style={{ minHeight: 200 }}>
        {/* Pattern bg */}
        <div className="absolute inset-0 opacity-10"
          style={{ backgroundImage: l.pattern === "circles" ? "radial-gradient(circle, rgba(255,255,255,0.3) 1px, transparent 1px)" : l.pattern === "dots" ? "radial-gradient(rgba(255,255,255,0.2) 1px, transparent 1px)" : "repeating-linear-gradient(45deg, rgba(255,255,255,0.05), rgba(255,255,255,0.05) 1px, transparent 1px, transparent 10px)", backgroundSize: "20px 20px" }} />
        {/* Label design */}
        <div className="relative p-5 flex flex-col h-full">
          <div className="flex items-start justify-between mb-3">
            <span className="text-3xl">{l.icon}</span>
            <span className="text-xs px-2 py-0.5 rounded-sm font-bold tracking-wider"
              style={{ backgroundColor: l.accent + "33", color: l.accent === "#1565c0" ? "#90caf9" : l.accent === "#2e7d32" ? "#a5d6a7" : "#fff", border: `1px solid ${l.accent}44`, fontFamily: "Montserrat, sans-serif" }}>
              {l.category}
            </span>
          </div>
          {/* Simulated label */}
          <div className="flex-1 bg-black/30 rounded-sm border border-white/10 p-3 mb-3 flex flex-col gap-2">
            <div className="h-2 bg-white/20 rounded-full w-3/4" />
            <div className="h-1.5 bg-white/10 rounded-full w-full" />
            <div className="h-1.5 bg-white/10 rounded-full w-2/3" />
            <div className="mt-2 flex gap-2">
              {[l.accent, "#ffffff33", "#cc000055"].map((c, ci) => (
                <div key={ci} className="h-4 rounded-sm flex-1" style={{ backgroundColor: c }} />
              ))}
            </div>
            <div className="h-1.5 bg-white/10 rounded-full w-full" />
            <div className="h-1.5 bg-white/10 rounded-full w-4/5" />
          </div>
          <h4 className="text-white font-bold text-sm" style={{ fontFamily: "Raleway, sans-serif" }}>{l.name}</h4>
          <p className="text-white/50 text-xs" style={{ fontFamily: "Montserrat, sans-serif" }}>Impression Flexo HD</p>
        </div>
        {/* Hover overlay */}
        <div className="absolute inset-0 bg-red-600/0 group-hover:bg-red-600/10 transition-all duration-300 flex items-center justify-center">
          <span className="opacity-0 group-hover:opacity-100 text-white font-bold text-xs tracking-widest uppercase border border-white/50 px-4 py-2 transition-all duration-300"
            style={{ fontFamily: "Montserrat, sans-serif" }}>
            Voir Détails
          </span>
        </div>
      </div>
    </Card3D>
  </motion.div>
);

const Realisations = () => (
  <section id="realisations" className="py-24 bg-black relative overflow-hidden">
    <div className="absolute inset-0 pointer-events-none"
      style={{ backgroundImage: "radial-gradient(circle at 50% 50%, rgba(204,0,0,0.05) 0%, transparent 70%)" }} />
    <div className="max-w-7xl mx-auto px-4">
      <FadeSection>
        <div className="text-center mb-16">
          <span className="inline-block text-red-500 text-xs font-bold tracking-[0.4em] uppercase mb-4"
            style={{ fontFamily: "Montserrat, sans-serif" }}>
            — Portfolio —
          </span>
          <h2 className="text-5xl md:text-6xl font-black text-white mb-4" style={{ fontFamily: "Raleway, sans-serif" }}>
            Nos <span className="text-red-600">Réalisations</span>
          </h2>
          <p className="text-gray-400 max-w-xl mx-auto text-sm" style={{ fontFamily: "Montserrat, sans-serif" }}>
            Des étiquettes et emballages conçus avec précision pour chaque secteur d'activité, selon les normes internationales.
          </p>
          <div className="h-0.5 bg-gradient-to-r from-transparent via-red-600 to-transparent max-w-xs mx-auto mt-4" />
        </div>
      </FadeSection>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {labels.map((l, i) => <LabelCard key={l.name} l={l} i={i} />)}
      </div>
    </div>
  </section>
);

// ─── Stats ─────────────────────────────────────────────────────────────────────
const stats = [
  { value: "500+", label: "Projets Réalisés" },
  { value: "100%", label: "Conformité ISO" },
  { value: "3", label: "Secteurs d'Activité" },
  { value: "24/7", label: "Support Client" },
];

const Stats = () => (
  <section className="py-16 bg-red-700 relative overflow-hidden">
    <div className="absolute inset-0"
      style={{ backgroundImage: "repeating-linear-gradient(45deg, rgba(0,0,0,0.05), rgba(0,0,0,0.05) 1px, transparent 1px, transparent 20px)" }} />
    <div className="max-w-6xl mx-auto px-4">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
        {stats.map((s, i) => (
          <motion.div key={s.label}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            viewport={{ once: true }}
            className="text-center"
          >
            <div className="text-4xl md:text-5xl font-black text-white mb-2" style={{ fontFamily: "Raleway, sans-serif" }}>{s.value}</div>
            <div className="text-red-200 text-xs tracking-widest uppercase" style={{ fontFamily: "Montserrat, sans-serif" }}>{s.label}</div>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

// ─── Contact ──────────────────────────────────────────────────────────────────
const Contact = () => {
  const [sent, setSent] = useState(false);
  const [form, setForm] = useState({ name: "", email: "", message: "" });
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSent(true);
    setTimeout(() => setSent(false), 3000);
    setForm({ name: "", email: "", message: "" });
  };
  return (
    <section id="contact" className="py-24 bg-zinc-950 relative overflow-hidden">
      <div className="absolute inset-0 pointer-events-none"
        style={{ backgroundImage: "radial-gradient(circle at 10% 50%, rgba(204,0,0,0.07) 0%, transparent 60%)" }} />
      <div className="max-w-6xl mx-auto px-4">
        <FadeSection>
          <div className="text-center mb-16">
            <span className="inline-block text-red-500 text-xs font-bold tracking-[0.4em] uppercase mb-4"
              style={{ fontFamily: "Montserrat, sans-serif" }}>
              — Parlons de Votre Projet —
            </span>
            <h2 className="text-5xl md:text-6xl font-black text-white mb-4" style={{ fontFamily: "Raleway, sans-serif" }}>
              Contactez-<span className="text-red-600">nous</span>
            </h2>
            <div className="h-0.5 bg-gradient-to-r from-transparent via-red-600 to-transparent max-w-xs mx-auto" />
          </div>
        </FadeSection>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
          {/* Info */}
          <FadeSection>
            <div className="space-y-8">
              <div>
                <div className="flex items-center gap-3 mb-2">
                  <EagleLogo size={48} />
                  <div>
                    <div className="text-white font-black text-2xl" style={{ fontFamily: "Raleway, sans-serif" }}>INGENIOUS GROUPS</div>
                    <div className="text-red-500 text-sm tracking-widest" style={{ fontFamily: "Montserrat, sans-serif" }}>Excellence & Innovation</div>
                  </div>
                </div>
                <p className="text-gray-400 text-sm leading-relaxed mt-4" style={{ fontFamily: "Montserrat, sans-serif" }}>
                  Leader algérien en conception graphique et impression flexographique pour les secteurs alimentaire, pharmaceutique et cosmétique. Nous garantissons une qualité aux standards internationaux.
                </p>
              </div>
              {/* Contact details */}
              {[
                { icon: "📞", label: "Téléphone", values: ["0798 23 45 79", "0777 29 24 80"] },
                { icon: "✉️", label: "Email", values: ["ingenious.24contact@gmail.com"] },
                { icon: "📍", label: "Localisation", values: ["Algérie"] },
              ].map(c => (
                <motion.div key={c.label} whileHover={{ x: 6 }} className="flex gap-4 items-start">
                  <div className="w-10 h-10 rounded-sm bg-red-950/50 border border-red-900/50 flex items-center justify-center text-xl flex-shrink-0">
                    {c.icon}
                  </div>
                  <div>
                    <div className="text-red-400 text-xs font-bold tracking-widest uppercase mb-1" style={{ fontFamily: "Montserrat, sans-serif" }}>{c.label}</div>
                    {c.values.map(v => (
                      <div key={v} className="text-white font-semibold text-sm" style={{ fontFamily: "Montserrat, sans-serif" }}>{v}</div>
                    ))}
                  </div>
                </motion.div>
              ))}
              {/* Certifications */}
              <div className="flex gap-3 flex-wrap">
                {["ISO 9001", "FLEXO", "PANTONE", "FDA"].map(c => (
                  <span key={c} className="text-xs px-3 py-1 border border-red-900/50 text-red-400 font-bold tracking-wider"
                    style={{ fontFamily: "Montserrat, sans-serif" }}>{c}</span>
                ))}
              </div>
            </div>
          </FadeSection>
          {/* Form */}
          <FadeSection>
            <Card3D>
              <form onSubmit={handleSubmit} className="bg-gradient-to-b from-zinc-900 to-zinc-950 border border-red-900/30 rounded-sm p-8 space-y-5">
                <div className="absolute top-0 left-0 right-0 h-0.5 bg-gradient-to-r from-transparent via-red-600 to-transparent" />
                {[
                  { id: "name", label: "Nom & Prénom", type: "text", placeholder: "Votre nom complet" },
                  { id: "email", label: "Adresse Email", type: "email", placeholder: "votre@email.com" },
                ].map(f => (
                  <div key={f.id}>
                    <label className="block text-red-400 text-xs font-bold tracking-widest uppercase mb-2"
                      style={{ fontFamily: "Montserrat, sans-serif" }}>{f.label}</label>
                    <input type={f.type} required value={form[f.id as keyof typeof form]}
                      onChange={e => setForm({ ...form, [f.id]: e.target.value })}
                      placeholder={f.placeholder}
                      className="w-full bg-black/50 border border-zinc-800 focus:border-red-600 text-white px-4 py-3 text-sm outline-none transition-colors rounded-sm placeholder-zinc-600"
                      style={{ fontFamily: "Montserrat, sans-serif" }} />
                  </div>
                ))}
                <div>
                  <label className="block text-red-400 text-xs font-bold tracking-widest uppercase mb-2"
                    style={{ fontFamily: "Montserrat, sans-serif" }}>Message</label>
                  <textarea required value={form.message} onChange={e => setForm({ ...form, message: e.target.value })}
                    rows={4} placeholder="Décrivez votre projet..."
                    className="w-full bg-black/50 border border-zinc-800 focus:border-red-600 text-white px-4 py-3 text-sm outline-none transition-colors rounded-sm placeholder-zinc-600 resize-none"
                    style={{ fontFamily: "Montserrat, sans-serif" }} />
                </div>
                <motion.button
                  type="submit"
                  whileHover={{ scale: 1.02, boxShadow: "0 0 25px rgba(204,0,0,0.5)" }}
                  whileTap={{ scale: 0.98 }}
                  className="w-full py-3.5 bg-red-600 hover:bg-red-700 text-white font-bold tracking-widest uppercase text-sm transition-colors rounded-sm border border-red-500"
                  style={{ fontFamily: "Montserrat, sans-serif" }}
                >
                  {sent ? "✓ Message Envoyé !" : "Envoyer le Message"}
                </motion.button>
              </form>
            </Card3D>
          </FadeSection>
        </div>
      </div>
    </section>
  );
};

// ─── Footer ───────────────────────────────────────────────────────────────────
const Footer = () => (
  <footer className="bg-black border-t border-red-900/30 py-10">
    <div className="max-w-7xl mx-auto px-4">
      <div className="flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="flex items-center gap-3">
          <EagleLogo size={44} />
          <div>
            <div className="text-white font-black text-lg" style={{ fontFamily: "Raleway, sans-serif" }}>INGENIOUS GROUPS</div>
            <div className="text-red-500 text-xs tracking-[0.25em]" style={{ fontFamily: "Montserrat, sans-serif" }}>Algérie · 2024</div>
          </div>
        </div>
        <div className="text-center">
          <p className="text-gray-500 text-xs" style={{ fontFamily: "Montserrat, sans-serif" }}>
            Design · Impression Flexo · Standards Internationaux
          </p>
          <p className="text-gray-600 text-xs mt-1" style={{ fontFamily: "Montserrat, sans-serif" }}>
            © 2024 INGENIOUS GROUPS. Tous droits réservés.
          </p>
        </div>
        <div className="text-right text-xs text-gray-500 space-y-1" style={{ fontFamily: "Montserrat, sans-serif" }}>
          <div>0798 23 45 79</div>
          <div>0777 29 24 80</div>
          <div className="text-red-600">ingenious.24contact@gmail.com</div>
        </div>
      </div>
    </div>
  </footer>
);

// ─── App ──────────────────────────────────────────────────────────────────────
export default function App() {
  return (
    <div className="bg-black min-h-screen" style={{ fontFamily: "Montserrat, sans-serif" }}>
      <Navbar />
      <Hero />
      <Services />
      <Stats />
      <Technologies />
      <Realisations />
      <Contact />
      <Footer />
    </div>
  );
}
